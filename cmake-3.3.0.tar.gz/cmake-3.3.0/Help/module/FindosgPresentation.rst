.. cmake-module:: ../../Modules/FindosgPresentation.cmake
