.. cmake-module:: ../../Modules/FindArmadillo.cmake
