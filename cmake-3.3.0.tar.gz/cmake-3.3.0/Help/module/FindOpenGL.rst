.. cmake-module:: ../../Modules/FindOpenGL.cmake
