.. cmake-module:: ../../Modules/FindosgAnimation.cmake
